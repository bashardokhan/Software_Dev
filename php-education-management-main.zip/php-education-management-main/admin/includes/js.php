  <!-- jQuery -->
  <script src="./src/js/jquery.min.js"></script>

  <!-- Bootstrap 4 -->
  <script src="./src/js/bootstrap.bundle.min.js"></script>

  <!-- SweetAlert2 -->
  <script src="./src/js/sweetalert2.min.js"></script>

  <!-- Toastr -->
  <script src="./src/js/toastr.min.js"></script>
  <script src="./src/js/adminlte.min.js"></script>