<!-- Favicon -->
<link rel="icon" type="image/x-icon" href="./favicon.ico">

<!-- Ionicons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<!-- Theme style -->
<link rel="stylesheet" href="./src/css/adminlte.min.css">

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

<!-- SweetAlert2 -->
<link rel="stylesheet" href="./src/css/sweetalert2-theme-bootstrap-4.css">

<!-- Toastr -->
<link rel="stylesheet" href="./src/css/toastr.min.css">